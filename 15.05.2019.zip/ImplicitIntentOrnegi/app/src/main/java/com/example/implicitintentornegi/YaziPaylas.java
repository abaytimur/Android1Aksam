package com.example.implicitintentornegi;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class YaziPaylas extends AppCompatActivity {
    EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yazi_paylas);
        editText = findViewById(R.id.editText);

        try {
            editText.setText((CharSequence) getIntent().getExtras().get(Intent.EXTRA_TEXT));
        } catch (Exception ex) {
        }
    }
}
