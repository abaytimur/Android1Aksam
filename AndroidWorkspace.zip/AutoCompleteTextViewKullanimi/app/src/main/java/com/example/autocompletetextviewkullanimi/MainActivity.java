package com.example.autocompletetextviewkullanimi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.MultiAutoCompleteTextView;

public class MainActivity extends AppCompatActivity {

    AutoCompleteTextView actv;
    MultiAutoCompleteTextView mactv;

    ArrayAdapter<String> arrayAdapter;
    String[] sehirler={"Kırklareli","Kırıkkale","Kırşehir","Kırgızistan","Ankara","Antalya","Aksaray","Adana","İstanbul","İstinye"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        actv = findViewById(R.id.actv);
        mactv = findViewById(R.id.mactv);

        arrayAdapter =new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_spinner_item,sehirler);
        mactv.setAdapter(arrayAdapter);
        actv.setAdapter(arrayAdapter);
        actv.setThreshold(1); //kaç karakterden sonra öneri sunsun
    }
}
